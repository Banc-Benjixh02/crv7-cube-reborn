import os
import json

# Define the search and replace strings
search_str = "cardgames"
replace_str = "item/cardgames"

# Loop through all files in the current directory
for filename in os.listdir("."):
    # Check if the file is a JSON file
    if filename.endswith(".json"):
        # Read the JSON data from the file
        with open(filename, "r") as f:
            data = json.load(f)

        # Replace the search string with the replace string in the JSON data
        json_str = json.dumps(data).replace(search_str, replace_str)

        # Write the updated JSON data back to the file
        with open(filename, "w") as f:
            f.write(json_str)
